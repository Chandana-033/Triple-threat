
# WeatherCast - Weather Forecast Service

A beautiful and user-friendly weather forecast application that provides accurate weather information for any location. Built with React, TypeScript, and Tailwind CSS.

## Features

- Current weather conditions display
- 5-day weather forecast
- Detailed weather information including temperature, humidity, wind speed, and more
- Location search functionality
- Responsive design that works on mobile, tablet, and desktop

## Technologies Used

This project is built with:

- Vite
- TypeScript
- React
- Tailwind CSS
- Lucide Icons
- React Router

## Project URL

**URL**: https://lovable.dev/projects/228885a4-1324-4f5b-9527-e504cfc04cf9

## How to Use

Simply visit the [WeatherCast App](https://lovable.dev/projects/228885a4-1324-4f5b-9527-e504cfc04cf9) and search for any location to get the current weather and forecast.

## Development

To run this project locally:

```sh
# Clone the repository
git clone <YOUR_GIT_URL>

# Navigate to the project directory
cd <YOUR_PROJECT_NAME>

# Install dependencies
npm i

# Start the development server
npm run dev
```

## Deployment

To deploy this application, open [Lovable](https://lovable.dev/projects/228885a4-1324-4f5b-9527-e504cfc04cf9) and click on Share -> Publish.
